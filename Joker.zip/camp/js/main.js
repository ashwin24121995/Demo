$('.open-popup-link').magnificPopup({
    type: 'inline',
    midClick: true
});